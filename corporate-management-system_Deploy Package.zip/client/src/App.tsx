import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/home";
import CompanyDetails from "@/pages/company-details";
import EmployeeDetail from "@/pages/employee-detail";
import DeploymentDownload from "@/pages/deployment-download";
import LoginPage from "@/pages/login";
import NotFound from "@/pages/not-found";
import { authService } from "@/lib/authService";
import { localStorageService } from "@/lib/localStorage";

// Migration function to calculate working hours for existing employees
function migrateEmployeeWorkingHours() {
  const migrationKey = "employee-working-hours-migrated";
  if (localStorage.getItem(migrationKey)) {
    return; // Already migrated
  }

  const employees = localStorageService.getEmployees();
  let updated = 0;

  employees.forEach((employee) => {
    // Only migrate if fields are missing and weeklyHours exists
    if (employee.weeklyHours > 0 && (!employee.dailyWorkingHours || !employee.endingWorkingTime)) {
      const weeklyHours = employee.weeklyHours;
      const startingTime = employee.startingWorkingTime || "09:00";

      // Calculate daily working hours: weeklyHours / 5
      const dailyWorkingHours = weeklyHours / 5;

      // Calculate ending working time: startingTime + dailyWorkingHours + 1 hour rest
      let endingWorkingTime: string | undefined = undefined;
      try {
        const [startHour, startMinute] = startingTime.split(':').map(Number);
        const startTotalMinutes = startHour * 60 + startMinute;
        const dailyMinutes = dailyWorkingHours * 60;
        const restMinutes = 60; // 1 hour rest
        const endTotalMinutes = startTotalMinutes + dailyMinutes + restMinutes;

        const endHour = Math.floor(endTotalMinutes / 60) % 24;
        const endMinute = Math.floor(endTotalMinutes % 60);
        endingWorkingTime = `${String(endHour).padStart(2, '0')}:${String(endMinute).padStart(2, '0')}`;

        // Update the employee
        localStorageService.updateEmployee(employee.id, {
          dailyWorkingHours,
          startingWorkingTime: startingTime,
          endingWorkingTime,
        });

        updated++;
        console.log(`[Migration] Updated employee ${employee.id}: daily=${dailyWorkingHours}, ending=${endingWorkingTime}`);
      } catch (e) {
        console.error(`[Migration] Error calculating for employee ${employee.id}:`, e);
      }
    }
  });

  localStorage.setItem(migrationKey, "true");
  console.log(`[Migration] Completed. Updated ${updated} employees with calculated working hours.`);
}

// Migration function to add whatsAppNumber field to existing dependants
function migrateDependantWhatsAppNumbers() {
  const migrationKey = "dependant-whatsapp-migrated";
  if (localStorage.getItem(migrationKey)) {
    return; // Already migrated
  }

  console.log('[Migration] Starting dependant WhatsApp number migration...');
  localStorageService.migrateWhatsAppNumberField();
  
  localStorage.setItem(migrationKey, "true");
  console.log('[Migration] Completed dependant WhatsApp number migration.');
}

// Run all migrations in sequence
function runMigrations() {
  migrateEmployeeWorkingHours();
  migrateDependantWhatsAppNumbers();
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/company/:id" component={CompanyDetails} />
      <Route path="/employee/:id" component={EmployeeDetail} />
      <Route path="/deployment" component={DeploymentDownload} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Verify authentication with server on mount
    async function verifyAuth() {
      try {
        const response = await fetch('/api/auth/me', { credentials: 'include' });
        const data = await response.json();
        
        if (data.user) {
          // Server has valid session - sync localStorage
          authService.setCurrentUser(data.user);
          setIsAuthenticated(true);
          
          // Run all migrations (each runs only once)
          runMigrations();
        } else {
          // Server session is missing - clear localStorage only (don't call logout endpoint)
          localStorage.removeItem('currentUser');
          setIsAuthenticated(false);
        }
      } catch (error) {
        console.error('Auth verification failed:', error);
        localStorage.removeItem('currentUser');
        setIsAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    }
    
    verifyAuth();
  }, []);

  const handleLoginSuccess = () => {
    // Clear ALL cached queries to ensure fresh data after login
    queryClient.clear();
    setIsAuthenticated(true);
  };

  // Show loading state briefly
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="text-lg font-medium">Loading...</div>
        </div>
      </div>
    );
  }

  // Show login page if not authenticated
  if (!isAuthenticated) {
    return (
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <LoginPage onLoginSuccess={handleLoginSuccess} />
        </TooltipProvider>
      </QueryClientProvider>
    );
  }

  // Show main app if authenticated
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
